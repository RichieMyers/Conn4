package com.androidatc.connectfour

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val NavBtn = findViewById<Button>(R.id.btn)
        NavBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this,Preferences::class.java)
            startActivity(intent)
        })
    }
}